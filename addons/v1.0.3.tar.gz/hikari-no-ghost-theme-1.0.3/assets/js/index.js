(function ($) {
  $(document).ready(function () {
    $('.post').fitVids();
  });
})(jQuery);
